package com.hcl.assignment;

import java.util.ArrayList;
import java.util.Scanner;

import com.hcl.assignment.beans.Employee;
import com.hcl.assignment.services.DataStructureA;
import com.hcl.assignment.services.DataStructureB;
import com.hcl.assignment.services.EmployeeServiceImpl;
import com.hcl.assignment.services.IEmployeeService;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        IEmployeeService empService = new EmployeeServiceImpl();
        DataStructureA structureA = new DataStructureA();
        DataStructureB structureB = new DataStructureB();
                
        int choice = 0;
        while(true){
            System.out.println("-----1: Add Employee | 2: Employee's List | 3: Sorted Employee's Name | 4: City's Count | 5: Monthly Salary | 6: Exit-----");
            System.out.print("Your Selection : ");
             //to handle inputMismatchExp
            while(!scan.hasNextInt()){
                System.out.println("input not a number!");
                scan.next();// important else infinite loop
                System.out.println("-----1: Add Employee | 2: Employee's List | 3: Sorted Employee's Name | 4: City's Count | 5: Monthly Salary | 6: Exit-----");
            }
            choice = scan.nextInt();
            if(choice > 0 && choice < 6){
                switch(choice){
                    case 1:
                        System.out.print("Employee Id: ");
                        Integer id = scan.nextInt();
                        System.out.print("Employee Name: ");
                        String name = scan.next();
                        System.out.print("Employee Age: ");
                        Integer age = scan.nextInt();
                        System.out.print("Employee Salary (Annum): ");
                        Integer salary = scan.nextInt();
                        System.out.print("Employee Department: ");
                        String dept = scan.next();
                        System.out.print("Employee City: ");
                        String city = scan.next();
                        Employee e = new Employee(id, name, age, salary, dept, city);
                        try {
                            empService.addEmployee(e);
                        } catch (IllegalArgumentException exp) {
                            exp.printStackTrace();
                            System.out.println();
                            System.out.println("Please re-enter employee data!");
                        }
                        break;
                    case 2:
                        System.out.println("List of employees");
                        System.out.println(empService.displayAllEmployee()); 
                        break;
                    case 3:
                        System.out.println("Names of all employees in the sorted order are ");
                        System.out.println(structureA.sortingNames(empService.getAllEmployee()));
                        break;
                    case 4:
                        System.out.println("Count of Employees from each city");
                        System.out.println(structureB.cityNameCount(empService.getAllEmployee())); 
                        break;
                    case 5:
                        System.out.println("Monthly Salary of employee along with their id is");
                        System.out.println(structureB.monthlySalary(empService.getAllEmployee()));
                        break;
                    case 6:
                        System.out.println("logging out...");
                        scan.close();
                        break;

                }
            }else{
                System.out.println("Invalid input range");
            }
        }
    }
}
