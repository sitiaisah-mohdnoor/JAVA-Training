package com.hcl.assignment.services;

import java.util.ArrayList;

import com.hcl.assignment.beans.Employee;

public interface IEmployeeService {
    
    public void addEmployee(Employee e);
    public String displayAllEmployee();
    public ArrayList<Employee> getAllEmployee();
}
