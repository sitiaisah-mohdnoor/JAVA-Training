package com.hcl.assignment.services;

import java.util.ArrayList;

import com.hcl.assignment.beans.Employee;

public class EmployeeServiceImpl extends Employee implements IEmployeeService{

    public EmployeeServiceImpl(int id, String name, int age, int salary, String department, String city) {
        super(id, name, age, salary, department, city);
        //TODO Auto-generated constructor stub
    }

    public EmployeeServiceImpl() {
        super();
    }

    @Override
    public void addEmployee(Employee e) {
        ArrayList<Employee> employees = super.getEmployees();
        if(e.getId() < 0){
            throw new IllegalArgumentException("Id cannot be negative value");
        }else if(e.getName() == "" || e.getName() == null){
            throw new IllegalArgumentException("Name cannot be empty");
        }else if(e.getAge() < 0){
            throw new IllegalArgumentException("Age cannot be negative value");
        }else if(e.getSalary() < 0){
            throw new IllegalArgumentException("Salary cannot be negative value");
        }else if(e.getDepartment() == "" || e.getDepartment() == null){
            throw new IllegalArgumentException("Department cannot be empty");
        }else if(e.getCity() == "" || e.getCity() == null){
            throw new IllegalArgumentException("City cannot be empty");
        }else{
            employees.add(e);
            super.setEmployees(employees);
        }
    }

    @Override
    public String displayAllEmployee() {       
        String display = "";
        ArrayList<Employee> employees = super.getEmployees();
        for(Employee emp: employees){ 
            display += "\n" + emp.getId() + " " + emp.getName() + " " + emp.getAge() + " " + emp.getSalary() + " " + emp.getDepartment() + " " + emp.getCity() ;
        }
        return display;

    }

    @Override
    public ArrayList<Employee> getAllEmployee() {
        return super.getEmployees();
    }
    
}
