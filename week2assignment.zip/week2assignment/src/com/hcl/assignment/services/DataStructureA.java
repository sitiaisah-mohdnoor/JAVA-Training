package com.hcl.assignment.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.hcl.assignment.beans.Employee;

public class DataStructureA{
    
    public String sortingNames(ArrayList<Employee> employees) {
        String res = "";
        Comparator<Employee> nameComp = new NameComparator();
        Collections.sort(employees, nameComp);
        for(Employee emp: employees){
            res += emp.getName() + " ";
            // System.out.print(emp.getName());
        }
        return res;
    }

}
