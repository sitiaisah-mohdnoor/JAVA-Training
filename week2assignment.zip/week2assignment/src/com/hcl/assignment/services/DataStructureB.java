package com.hcl.assignment.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.hcl.assignment.beans.Employee;

public class DataStructureB {

    public Map<String, Long> cityNameCount(ArrayList<Employee> employees) {
        Map<String, Long> cityCollection = new HashMap<>();
        try {
            ArrayList<String> cities = new ArrayList<>();
            for(Employee emp : employees){
                cities.add(emp.getCity());
            }
            //or use method reference 
            //cityCollection = employees.stream().collect(Collectors.groupingBy(Employee::getCity,Collectors.counting()));

            //or
            Map<String, Integer> cityList = new HashMap<>();
            cityList = employees.stream().collect(Collectors.toMap(Employee::getCity, Employee::getId));
            System.out.println(cityList);
            //or
            cityCollection = cities.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cityCollection;
    }
    
    public Map<Integer, Double> monthlySalary(ArrayList<Employee> employees) {
        Map<Integer, Double> salaryCollection = new TreeMap<>();
        try {
            // for(Employee emp : employees){
            //     Double monthlySalary = (double) (emp.getSalary() / 12);
            //     salaryCollection.put(emp.getId(), monthlySalary);
            // }

            //stream approach
            Map<Object, Object> s = employees.stream().collect(Collectors.toMap(x -> x.getId(), x -> (x.getSalary()/12)));
            System.out.println(s);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return salaryCollection;
    }
}
