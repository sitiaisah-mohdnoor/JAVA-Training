package com.hcl.banking.demo;

import java.util.ArrayList;
import java.util.List;

public class Customer {
    private String accountNo;
    private String accountPwd;
    private double accountBalance;
    private List<Customer> ctmList = new ArrayList<>();

    //constructor

    // Customer(){

    // }

    // Customer(String acc, String pwd, double blc){
    //     this.accountNo = acc;
    //     this.accountPwd = pwd;
    //     this.accountBalance = blc;
    // }

    public Customer authenticateLogin(String accNo, String accPwd){
        Customer find = this.ctmList.stream().filter(Customer -> accNo.equals(Customer.getAccountNo())).findFirst().orElse(null);
        // System.out.print("find" + find);
        if(accPwd.equals(find.accountPwd)){
            return find;
        }else{
            return null;
        }
    }

    /**
     * @return String return the accountNo
     */
    public String getAccountNo() {
        return accountNo;
    }

    /**
     * @param accountNo the accountNo to set
     */
    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    /**
     * @return String return the accountPwd
     */
    public String getAccountPwd() {
        return accountPwd;
    }

    /**
     * @param accountPwd the accountPwd to set
     */
    public void setAccountPwd(String accountPwd) {
        this.accountPwd = accountPwd;
    }

    /**
     * @return double return the accountBalance
     */
    public double getAccountBalance() {
        return accountBalance;
    }

    /**
     * @param accountBalance the accountBalance to set
     */
    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }

    @Override
    public String toString() {
        return "{" +
            " accountNo='" + getAccountNo() + "'" +
            ", accountPwd='" + getAccountPwd() + "'" +
            ", accountBalance='" + getAccountBalance() + "'" +
            "}";
    }


    /**
     * @return List<Customer> return the ctmList
     */
    public List<Customer> getCtmList() {
        return ctmList;
    }

    /**
     * @param ctmList the ctmList to set
     */
    public void setCtmList(List<Customer> ctmList) {
        this.ctmList = ctmList;
    }

}
