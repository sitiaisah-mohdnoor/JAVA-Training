package com.hcl.banking.demo;

import java.util.Scanner;

public class Bank {
    static Customer currCtm = null;
    public static void main(String[] args) {

            Services serv = new Services();
            Scanner scan = new Scanner(System.in);

            start(scan, serv);
            //TODO enhance input validation 
            int choice = 0;
            while(true){
                System.out.println("-----1: Deposit | 2: Withdraw | 3: Transfer | 4: Balance | 5: Logout-----");
                System.out.print("Please input here: ");
                 //to handle inputMismatchExp
                while(!scan.hasNextInt()){
                    System.out.println("input not a number!");
                    scan.next();// important else infinite loop
                    System.out.println("-----1: Deposit | 2: Withdraw | 3: Transfer | 4: Balance | 5: Logout-----");
                }
                choice = scan.nextInt();
                if(choice > 0 && choice < 6){
                    switch(choice){
                        case 1:
                            System.out.print("Please input deposit amount: ");
                            double depoAmt = scan.nextDouble();
                            System.out.println("Current Balance: "+ serv.addDeposit(depoAmt, currCtm));
                            break;
                        case 2:
                            System.out.print("Please input withdraw amount: ");
                            double drawAmt = scan.nextDouble();
                            try {
                                System.out.println("Current Balance: "+ serv.withdrawMoney(drawAmt, currCtm));
                            } catch (CustomerException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 3:
                            System.out.print("Please input transfer amount: ");
                            double transferAmt = scan.nextDouble();
                            double crrBal = serv.checkBalance(currCtm);
                            if(transferAmt > crrBal) System.out.println("Account balance not enough to be transferred");
                            else{
                                System.out.print("Please input transfer account: ");
                                String transferAcc = scan.next();
                                String otp = serv.genOTP();
                                System.out.println("Here is your 6 digit OTP: "+ otp);
                                System.out.println("Current Balance: "+ serv.transferMoney(transferAmt, transferAcc, otp, currCtm));
                            }      
                            break;
                        case 4:
                            System.out.println("Your Balance: "+ serv.checkBalance(currCtm));
                            break;
                        case 5:
                            System.out.println("logging out...");
                            start(scan, serv);
                            break;

                    }
                }else{
                    System.out.println("Invalid input range");
                }
            }
    }

    static void service(Scanner scan, Services serv){

    }
    static void start(Scanner scan, Services serv){
        int select = 0;
        while(select != 2){
            System.out.println("-----1: New Customer | 2: Existing Customer-----");
            System.out.print("Please input here: ");
            //to handle inputMismatchExp
            while(!scan.hasNextInt()){
                System.out.println("input not a number!");
                scan.next();// important else infinite loop
                System.out.println("-----1: New Customer | 2: Existing Customer-----");
            }
            select = scan.nextInt();
            switch(select){
                case 1:
                    System.out.print("Set Account No: ");
                    String newAccNo = scan.next();
                    System.out.print("Set Account Password: ");
                    String newAccPwd = scan.next();
                    System.out.print("Set Account Balance: ");
                    double newAccBlc = scan.nextDouble();
                    serv.addCustomer(newAccNo, newAccPwd, newAccBlc);
                    break;
                case 2:
                    System.out.println("fetch list"+ serv.getCtmList());
                    while(currCtm == null){
                        System.out.print("Account No: ");
                        String accNo = scan.next();
                        System.out.print("Account Password: ");
                        String accPwd = scan.next();
            
                        System.out.println("Authenticating....");
                        currCtm = serv.authenticateLogin(accNo, accPwd);
                        // System.out.println("Customer"+ success);
                        if(currCtm != null) {System.out.println("successfull"); break;}
                        else System.out.println("failed");
                    }
                    break;

            }
        }
    }
}
