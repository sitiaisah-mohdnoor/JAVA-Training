package com.hcl.banking.demo;

public class CustomerException extends Exception{

    public CustomerException(String msg){
        super(msg);
    }
}
