package com.hcl.banking.demo;

import java.util.List;
import java.util.Random;

public class Services extends Customer{

    public double checkBalance(Customer ctmAcc){
        return ctmAcc.getAccountBalance();//super.getAccountBalance();
    }

    public double addDeposit(double amt, Customer ctmAcc){
        double currentBlc = ctmAcc.getAccountBalance(); //super.getAccountBalance();
        // System.out.println("currentBlc"+ currentBlc);
        currentBlc += amt;
        //this.setAccountBalance(currentBlc);
        ctmAcc.setAccountBalance(currentBlc);
        return currentBlc;
    }

    public String withdrawMoney(double amt, Customer ctmAcc) throws CustomerException{
        double currentBlc = ctmAcc.getAccountBalance(); //super.getAccountBalance();
        if(amt < currentBlc){
            currentBlc -= amt;
            ctmAcc.setAccountBalance(currentBlc);
            return " " + currentBlc;
        }else{
            throw new CustomerException("Account balance not enough for withdrawal");
            //return "Account balance not enough for withdrawal";
        }
    }

    public String genOTP(){
        Random rand =  new Random();
        int otp = rand.nextInt(999999);
        return String.format("%06d", otp);
    }

    public String transferMoney(double amt, String toAcc, String otp, Customer ctmAcc){
        double currentBlc = ctmAcc.getAccountBalance(); //super.getAccountBalance();
        currentBlc -= amt;
        ctmAcc.setAccountBalance(currentBlc);
        return " " + currentBlc;
    }

    public void addCustomer(String accNo, String accPwd, double accBlc){
        List<Customer> ctmList = super.getCtmList();
        System.out.println("before adding "+ctmList);
        Customer newCtm = new Customer();
        newCtm.setAccountNo(accNo);
        newCtm.setAccountPwd(accPwd);
        newCtm.setAccountBalance(accBlc);
        ctmList.add(newCtm);
        System.out.println("updated list"+ctmList);
    }

}
