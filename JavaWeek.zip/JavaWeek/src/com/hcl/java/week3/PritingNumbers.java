package com.hcl.java.week3;

import java.util.ArrayList;

public class PritingNumbers implements Runnable{
    private String choice;

    public PritingNumbers(String ch) {
        this.choice = ch;
    }

    @Override
    public void run() {
        System.out.println("running "+ Thread.currentThread().getName());
        ArrayList<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= 20; i++) {
            numbers.add(i);
        }
        switch (choice) {
            case "even":
            System.out.println("even");
                for(Integer num : numbers){
                    if(num%2 == 0){
                        System.out.println(num);
                    }              
                } 
                break;
        
            case "odd":
            System.out.println("odd");
                for(Integer num : numbers){
                    if(num%2 != 0){
                        System.out.println(num);
                    }       
                } 
                break;
        }      
           
        
    }

}
