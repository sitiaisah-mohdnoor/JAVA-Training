package com.hcl.java.week3;

public class Greet extends Thread{
    
    private String guestname;

    public Greet(String s) {
        this.guestname = s;
    }

    public Greet() {
    }

    public Runnable printGreeting(String guestname){
        System.out.println("running "+ Thread.currentThread().getId());
        try {
            System.out.println("welcome "+ guestname);
            System.out.println("how are u doing " + guestname);
            System.out.println("Goodbye for now, see you soon " + guestname);
            Thread.sleep(250);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void run(){
        //printGreeting(guestname);
        System.out.println("running "+ Thread.currentThread().getName());
    }
}
