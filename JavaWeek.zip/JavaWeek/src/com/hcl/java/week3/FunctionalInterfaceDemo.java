package com.hcl.java.week3;

public class FunctionalInterfaceDemo {
    public static void main(String[] args) {
        CovidImmunable covidImmunable = () -> System.out.println("get vaccine");
        covidImmunable.getCoviceVaccine();
    }
}


@FunctionalInterface
interface CovidImmunable{
    public void getCoviceVaccine();
    //public void secondMethod();//will throw error as it can contain only one abstract method
}