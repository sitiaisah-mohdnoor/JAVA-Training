package com.hcl.java.week3;

public class ThreadPool implements Runnable {
	private String message;
	
	public ThreadPool(String msg) {
		this.message = msg;
	}

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName());
		printMsg();
		System.out.println(Thread.currentThread().getName());
		// TODO Auto-generated method stub
	
		
	}
	private void printMsg() {
		try {
			Thread.sleep(2000);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}

}

