package com.hcl.java.week3;

@FunctionalInterface
public interface MathOperation {
    public Integer operate(Integer num1, Integer num2);

}
