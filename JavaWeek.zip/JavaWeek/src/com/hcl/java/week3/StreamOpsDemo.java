package com.hcl.java.week3;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamOpsDemo {
    public static void main(String[] args) {
        /**
         * Intermediate Ops
         */

        // List<String> names = new ArrayList<>();
        // names.add("vishwa");
        // names.add("rahul");
        // names.add("ali");
        // names.add("rahul");
        // Stream<String> namesStream = names.stream();

        // Stream<String> sortedNum = namesStream.sorted();
        // sortedNum.forEach( name -> System.out.println(name + " "));
        // System.out.println();

        // Stream<String> distinctNames = namesStream.distinct();
        // distinctNames.forEach( name -> System.out.println(name + " "));
        // System.out.println();

        // Stream<Integer> numbers = Stream.of(1,2,3,4,5);
        // Stream<Integer> squaredNum = numbers.map(num -> num*num);
        // squaredNum.forEach(num -> System.out.println(num));

        // Stream<Integer> numbers = Stream.of(1,2,3,4,5);
        // Stream<Integer> evenNumbers = numbers.filter(num -> num%2 ==0);
        // evenNumbers.forEach(num -> System.out.println(num));

        // Stream<Integer> numbers = Stream.of(1,2,3,4,5,6,7,8,9);
        // Stream<Integer> truncNumbers = numbers.limit(4);
        // truncNumbers.forEach(num -> System.out.println(num));

        /**
         * Terminal Ops
         */
        // Stream<Integer> numbers = Stream.of(1,2,3,4,5,6,7,8,9);
        // System.out.println(numbers.count());

        // Stream<Integer> numbers = Stream.of(1,2,3,4,5,6,7,8,9);
        // List<Integer> numList = numbers.collect(Collectors.toList());
        // System.out.println(numList);

        //lab week3 day4
        Stream<Integer> numbers = Stream.of(1,2,3,4,5,6,7,8,9);
        // List<Integer> oddNumbers = numbers.filter(num -> num%2 != 0).map(num -> num*num).collect(Collectors.toList());
        // System.out.println(oddNumbers);
        // Integer max =  oddNumbers.stream().mapToInt(val -> val).max().orElseThrow(NoSuchElementException::new);
        // System.out.println(max);

        // Optional<Integer> oddNumbers = numbers.filter(num -> num%2 != 0).map(num -> num*num).reduce(Integer::max);//.orElseThrow(NoSuchElementException::new);
        // System.out.println(oddNumbers);
        
        //other way
        Optional<Integer> largest = numbers.filter(num -> num%2 != 0).map(num -> num*num).sorted().max(Integer::compare);
        System.out.println(largest);

        List<Employee> list = new ArrayList<>();
        list.add(new Employee(1,"john",50000,"Dev"));
        list.add(new Employee(2,"sam",30000,"Sales"));
        list.add(new Employee(3,"bob",60000,"Dev"));
        list.add(new Employee(4,"amy",40000,"HR"));
        System.out.println(list);
        double average_method1 = list.stream().filter(e -> e.getDept().equals("Dev")).collect(Collectors.averagingInt(x -> x.getSalary()));
        System.out.println(average_method1);
        List<Employee> filtered = list.stream().filter(e -> e.getDept().equals("Dev")).collect(Collectors.toList());
        //filtered.forEach(x -> System.out.println(x));
        System.out.println(filtered);
        // IntStream salaries = filtered.stream().mapToInt( x -> x.getSalary());
        // System.out.println(salaries);
        OptionalDouble average = filtered.stream().mapToInt(x -> x.getSalary()).average();//.orElseThrow(NoSuchElementException::new);
        System.out.println(average);


    }

}

class Employee{
    private int id;
    private String name;
    private int salary;
    private String dept;

    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            ", name='" + getName() + "'" +
            ", salary='" + getSalary() + "'" +
            ", dept='" + getDept() + "'" +
            "}";
    }

    public Employee(int id, String name, int salary, String dept) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.dept = dept;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @param salary the salary to set
     */
    public void setSalary(int salary) {
        this.salary = salary;
    }

    /**
     * @param dept the dept to set
     */
    public void setDept(String dept) {
        this.dept = dept;
    }


    /**
     * @return int return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @return String return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return int return the salary
     */
    public int getSalary() {
        return salary;
    }

    /**
     * @return String return the dept
     */
    public String getDept() {
        return dept;
    }

}
