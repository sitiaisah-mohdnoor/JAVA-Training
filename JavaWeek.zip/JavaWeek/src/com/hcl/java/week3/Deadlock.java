package com.hcl.java.week3;
public class Deadlock {
	public static void main(String [] args) {
		final String name1 = "Java Sessions";
		final String name2 = "MySql Sessions";
		Thread th1 = new Thread() {
			public void run() {
				synchronized (name1) {
					System.out.println("Thread 1: locked name1");
					try {
						Thread.sleep(100);
						
					}catch(Exception ex) {
						ex.printStackTrace();
					}
				
				synchronized (name2) {
					System.out.println("Thread 1: Locked name 2");
					
				}
				}
			}
		};
		Thread th2 = new Thread() {
			public void run() {
				synchronized (name2) {
					System.out.println("Thread 2: locked name2");
					try {
						Thread.sleep(100);
						
					}catch(Exception ex) {
						ex.printStackTrace();
					}
				
				synchronized (name1) {
					System.out.println("Thread 2: Locked name 1");
					
				}}
			}
		};
		th1.start();
		th2.start();
	}
}
