package com.hcl.java.week3;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

public class Thread1 implements Runnable{

    // ArrayList<String> obj;
    CopyOnWriteArrayList<String> obj;

    public Thread1(CopyOnWriteArrayList<String> obj) {
        this.obj = obj;
    }

    @Override
    public void run() {
        try {
            for(String ar: obj){
                System.out.println("print value "+ ar);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
