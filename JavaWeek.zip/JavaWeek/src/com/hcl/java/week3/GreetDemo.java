package com.hcl.java.week3;

public class GreetDemo {
    public static void main(String[] args) {
        Greet greet = new Greet();

        Thread t1 = new Thread(greet.printGreeting("guest1"), "threa1");
        Thread t2 = new Thread(greet.printGreeting("guest2"), "threa2");
        Thread t3= new Thread(greet.printGreeting("guest3"), "threa3");

        t1.start();
        t2.start();
        t3.start();
    }
}
