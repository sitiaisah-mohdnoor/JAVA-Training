package com.hcl.java.week3;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

public class ConcurrentCollectionImpl {
    public static void main(String[] args) {
        // ArrayList<String> arr = new ArrayList<>();
        CopyOnWriteArrayList<String> arr = new CopyOnWriteArrayList<>();
        arr.add("haha");
        arr.add("hihi");
        arr.add("huhu");

        Thread1 t1 = new Thread1(arr);
        Thread2 t2 = new Thread2(arr);

        Thread th1 = new Thread(t1);
        Thread th2 = new Thread(t2);

        th1.start();
        th2.start();

    }
}
