package com.hcl.java.week3;

import java.util.function.Supplier;

public class SupplierDemo {
    public static void main(String[] args) {
        Supplier<String> supp = () -> {return "helloooo";};
        System.out.println(supp.get());
    }
}
