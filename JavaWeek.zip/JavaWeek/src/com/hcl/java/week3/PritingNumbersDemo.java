package com.hcl.java.week3;

public class PritingNumbersDemo {
    public static void main(String[] args) {

        PritingNumbers even = new PritingNumbers("even");
        PritingNumbers odd = new PritingNumbers("odd");

        Thread t1 = new Thread(even,"thread even");
        Thread t2 = new Thread(odd, "thread odd");

        t1.start();
        // try {
        //     t1.join();
        // } catch (InterruptedException e) {
        //     // TODO Auto-generated catch block
        //     e.printStackTrace();
        // }
     
        t2.start();
    }
}
