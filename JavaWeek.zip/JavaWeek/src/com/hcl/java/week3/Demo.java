package com.hcl.java.week3;



public class Demo extends Thread{

    public void run() {

        System.out.print(" running...");
        
        }

    public static void main(String[] args) {

        IShape circle = () -> {
            return 3.142*10*10;
        };

        IShape square = () -> {
            return 10*10;
        };

        System.out.println("circle "+circle.calcArea());
        System.out.println("square "+square.calcArea());

        Scanner scan = new Scanner(System.in);
        System.out.print("enter number ");
        Integer num1 = scan.nextInt();
        System.out.print("enter number ");
        Integer num2 = scan.nextInt();
        MaxFinder finder = (n1, n2) -> {
            return n1 > n2? n1:n2;
        };
        System.out.println("Largest "+finder.findMaximumNumber(num1, num2)); 

        MathOperation plus = (n1,n2) -> n1+n2;
        System.out.println("plus "+ plus.operate(5, 5));

        MathOperation minus = (n1,n2) -> n2-n1;
        System.out.println("minus "+ minus.operate(5, 5));

        MathOperation multi = (n1,n2) -> n1*n2;
        System.out.println("multi "+ multi.operate(5, 5));

        MathOperation divide = (n1,n2) -> n1/n2;
        System.out.println("divide "+ divide.operate(5, 5));
    }
}
