package com.hcl.java.week3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileHandlingDemo {
    public static void main(String[] args) {
        File file = new File("myFile.txt");

        try {
            FileWriter fileWriter = new FileWriter(file, true);
            fileWriter.write("my first statement");
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally{
            
        }

        try {
            FileReader fileReader = new FileReader(file);
            int myChar = -1;
            while((myChar = fileReader.read()) != -1){
                System.out.println((char)myChar);
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println();

    }
}
