package com.hcl.java.week3;

@FunctionalInterface
public interface IShape {
    
    public double calcArea();
}
