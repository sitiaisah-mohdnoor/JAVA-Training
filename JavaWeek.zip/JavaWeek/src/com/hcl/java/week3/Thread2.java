package com.hcl.java.week3;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

public class Thread2 implements Runnable{
    // ArrayList<String> obj;
    CopyOnWriteArrayList<String> obj;

    public Thread2(CopyOnWriteArrayList<String> obj) {
        this.obj = obj;
    }

    @Override
    public void run() {
        try {
            obj.add("popo");
            //will cause java.util.ConcurrentModificationException
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
}
