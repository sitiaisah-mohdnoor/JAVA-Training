package com.hcl.java.week3;

@FunctionalInterface
public interface MaxFinder {
    public Integer findMaximumNumber(Integer num1, Integer num2);
}
