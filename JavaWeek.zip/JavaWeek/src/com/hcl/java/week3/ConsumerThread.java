package com.hcl.java.week3;

import java.util.concurrent.BlockingQueue;

public class ConsumerThread implements Runnable{
    BlockingQueue<String> obj;

    // Initialize taken to -1
    // to indicate that no number
    // has been taken so far.
    int taken = -1;

    public ConsumerThread(BlockingQueue<String> obj){
        this.obj = obj;
    }

    @Override
    public void run() {
        //Take numbers from the buffer 
        while (taken != 4) {
            try {
                String taken = obj.take();
                System.out.println("Consumed "+ taken);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    
}
