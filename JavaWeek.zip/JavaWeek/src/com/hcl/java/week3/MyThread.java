package com.hcl.java.week3;

public class MyThread implements Runnable{

    @Override
    public void run() {
        System.out.println("running thread "+ Thread.currentThread().getName());
        try {
            long start = System.currentTimeMillis();
            System.out.println("pausing...");
            Thread.sleep(3000); // pause
            System.out.println("Sleep time in ms = "+(System.currentTimeMillis()-start));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
}
