package com.hcl.java.week3;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Executor;
public class ThreadPoolMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExecutorService executor = Executors.newFixedThreadPool(10);
		for(int counter = 0;counter<10;counter++) {
			Runnable thPoolDemo = new ThreadPool(" "+counter);
			executor.execute(thPoolDemo);
		}
		executor.shutdown();
		while(!executor.isTerminated()) {}
		System.out.println("All Threads are over");

	}

}

