package com.hcl.java.week3;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

/**
 *  Producer-Consumer problem is a synchronization issue that arises 
 *  when one or more threads generate data, placing it on a buffer, and 
 *  simultaneously, one or more threads consume data from the same buffer
 * 
 * Solutions:
 *  1. wait() & notify() methods can be used to establish inter-thread communication.
    2. BlockingQueue is a less-complex thread-safe alternative to wait() & notify(). 

    If a producer thread tries to put an element in a full BlockingQueue, 
    it gets blocked and stays blocked until a consumer removes an element.

    Similarly, if a consumer thread tries to take an element from an empty BlockingQueue,
    it gets blocked and remains blocked until a producer adds an element.
 */
public class ProducerConsumerImpl {
    public static void main(String[] args) {
         // Create an ArrayBlockingQueue object with capacity 4
         BlockingQueue<String> bqueue = new ArrayBlockingQueue<String>(4);
        // Create 1 object each for producer
        // and consumer and pass them the common
        // buffer created above
        ProducerThread p1 = new ProducerThread(bqueue);
        ConsumerThread c1 = new ConsumerThread(bqueue);
        // Create 1 thread each for producer
        // and consumer and pass them their
        // respective objects
        Thread pThread = new Thread(p1);
        Thread cThread = new Thread(c1);
        // Start both threads
        pThread.start();
        cThread.start();
    }
}
