package com.hcl.java.week3;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

public class IOStreamDemo {
	// public static void main(String args[]) throws Exception {
	// 	FileOutputStream fout = new FileOutputStream("output.txt");
	// 	BufferedOutputStream bout = new BufferedOutputStream(fout);
	// 	String str = "This is second IO Example";
	// 	byte b[] = str.getBytes();
	// 	bout.write(b);
	// 	bout.flush();
	// 	fout.close();
	// 	System.out.println("File is created with output");
	// }

    // public static void main(String args[]) throws Exception {
    //     FileOutputStream fout = new FileOutputStream("output.txt");
    //     DataOutputStream dout = new DataOutputStream(fout);
    //     // dout.writeChars("Hello this is an input Stream Example");
    //     dout.writeChar(65);
    //     dout.flush();
    //     fout.close();
    //     System.out.println("Data output Exampe");           
    // }

    public static void main(String[] args) throws Exception {
		PrintStream out = new PrintStream(new File("output.txt"));
		System.setOut(out);
		System.out.println("Hello PrintStream Example");

	}

    
}
