package com.hcl.java.week3;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class LamdaDemo {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>();
        numbers.add(1);
        numbers.add(2);
        numbers.add(3);
        numbers.add(4);
        numbers.add(5);

        /**
         * before java 1.8 lambda exp, iterating given list
         */
        for (int num : numbers) {
            System.out.println(num + " ");
        }

        /**
         * achieving same using lambda
         */
        System.out.println("using lambda");
        numbers.forEach( n -> System.out.println(n + " "));

        /**
         * there is no args : () -> { logics }
         */
        /**
         * before java 8
         */
        MathsNumber math = new MathsNumber(){
            // Random _rand = new Random();
            // @Override
            // public void randomNumber(){
            //     System.out.println(_rand.nextInt());
            // }
            public int getSquare(int num){
                return num*num;
            }
        };
        // math.randomNumber();
        System.out.println(math.getSquare(5));

        /**
         * implementing the same using java 8
         */
        // MathsNumber m = () -> {
        //     Random _rand = new Random();
        //     System.out.println(_rand.nextInt());
        // };
        // m.randomNumber();
        System.out.println("using lambda");
        MathsNumber math2 = (num) -> num*num;
        System.out.println(math2.getSquare(5));
        
    }
}

interface MathsNumber{
    // public void randomNumber();
    public int getSquare(int num);
}

