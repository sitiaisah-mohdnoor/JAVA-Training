package com.hcl.java.week3;

import java.util.concurrent.BlockingQueue;

public class ProducerThread implements Runnable{

    BlockingQueue<String> obj;

    public ProducerThread(BlockingQueue<String> obj){
        // accept an ArrayBlockingQueue object from constructor
        this.obj = obj;
    }

    @Override
    public void run() {
        //inserts Strings into the blocking-queue. It sleeps for 1000ms between each put call. 
        //(This is to cause the Consumer to block, while waiting for objects in the queue.)
        try {
            for (int i = 1; i <= 4; i++) {
                obj.put(i + "");
                System.out.println("Produced " + i);
                Thread.sleep(1000);
            }
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
        
    }
    
}
