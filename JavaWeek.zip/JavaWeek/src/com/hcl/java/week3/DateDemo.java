package com.hcl.java.week3;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class DateDemo {
    public static void main(String[] args) {
        LocalDateTime currTime = LocalDateTime.now();
        System.out.println(currTime.getDayOfMonth()+"-"+currTime.getMonth()+"-"+currTime.getYear());
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("E, MMMM dd yyyy h:m:s a");
        String today = dateFormat.format(currTime);
        System.out.println(today);

        String month = currTime.getMonth().name();
        System.out.println(month);

        LocalDateTime futureTime = currTime.plusDays(5);
        System.out.println(futureTime);
        
        LocalDateTime randomTime = LocalDateTime.of(1991, 12, 6, 07, 07, 07);
        System.out.println(randomTime);

        ZonedDateTime  cTime = ZonedDateTime.now();
        System.out.println(cTime);

        ZoneId zoneId = ZoneId.of("Europe/Paris");
        ZonedDateTime zTime = ZonedDateTime.of(randomTime, zoneId);
        System.out.println(zTime);
    }
}
