package com.hcl.java.week2;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

public class LinkedListImplementation {
    public static void main(String[] args){
        LinkedList<Integer> linked = new LinkedList<>();
        Scanner scan = new Scanner(System.in);
        int count = 0;
        while(count <=5 ){
            System.out.print("input: ");
            int ipt = scan.nextInt();
            linked.add(ipt);
            count++;
        }
        Collections.sort(linked);
        System.out.println(linked);
        Collections.reverse(linked);
        System.out.println(linked);

    }
}
