package com.hcl.java.week2;
/**
 * Type Parameter
 * T -> Type --generic type parameter passed to generic class
 * E -> Element
 * K -> Key
 * N -> Number
 * V -> Value
 * 
 * 
 * Generic's wildcards -- aimed to make it possible to cast a collection of a certain class | target the needs to read/insert from/into generic collection
 * 
 * unknown wildcard
 *  List<?> -- represent list of unknown types | can ONLY READ from collection | treat object ead as OBJECT INSTANCE
 *  public void processElements(List<?> elements){
    for(Object o : elements){
        System.out.println(o);
    }}

 * extends wildcard (upperbound) -- best suite for variable that provides sta to the code
 *  List<? extends A> -- List of objects that are instances of class A or subclass of A |safe to read instances of coll and cast them to A instance
 *  public void processElements(List<? extends A> elements){
    for(A a : elements){
      System.out.println(a.getValue());
    }}
 * 
 * super wildcard (Lowerbound) -- best suite for variable that holds data updated by code
 *  List<? super A> -- typed to either A class or superclass of A | safe to insert instance of A or subclass of A
 *  public static void insertElements(List<? super A> list){
    list.add(new A());
    list.add(new B());
    list.add(new C());
    }
 */

 public class GenericDemo{
    public static void main(String[] args) throws Exception {
        //Generic example, will throw compile time error when we pass wrong type
        GenericClass<String> obj1 = new GenericClass<>();
        obj1.setMyObj("ali");
        System.out.println(obj1.getMyObj());
        GenericClass<Integer> obj2 = new GenericClass<>();
        obj2.setMyObj(123);
        System.out.println(obj2.getMyObj());

        GenericMethod genMet = new GenericMethod();
        Integer[] arrI = {1,2,3};
        String[] arrS = {"ali", "abu"};
        genMet.printElements(arrI);
        genMet.printElements(arrS);

    }
 }

/** Generic class */
class GenericClass<T> {
    private T myObj;
    
    /**
     * @return T return the myObj
     */
    public T getMyObj() {
        return myObj;
    }

    /**
     * @param myObj the myObj to set
     */
    public void setMyObj(T myObj) {
        this.myObj = myObj;
    }

}

/** Generic method */
class GenericMethod{
    public <E> void printElements(E[] elms){
        for(int i=0; i<elms.length; i++){
            System.out.println(elms[i]);
        }
    }
}
