package com.hcl.java.week2;

import java.util.ArrayList;

public class ArrayListImplementation {

    public static void main(String[] args){
        ArrayList<Integer> arrList = new ArrayList<>();
        arrList.add(5);
        arrList.add(10);
        arrList.add(15);
        System.out.println("size: "+ arrList.size());
        if(arrList.size() > 1){
            int idx = arrList.indexOf(10);
            arrList.remove(idx);
        }
        for(int el: arrList){
            System.out.print(el+" ");
        }
    }
    
}
