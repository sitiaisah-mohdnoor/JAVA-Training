package com.hcl.java.week2;

import java.util.Iterator;
import java.util.Scanner;
import java.util.Stack;

public class StackImplm {
    public static void main(String[] args){
        Stack<String> stck = new Stack<>();
        Scanner scan = new Scanner(System.in);
        int count = 0;
        while(count <=5 ){
            System.out.print("input: ");
            String ipt = scan.next();
            stck.push(ipt);
            count++;
        }
        System.out.println(stck);
        Iterator<String> iterate = stck.iterator();
        while(iterate.hasNext()){
            System.out.println(iterate.next());
        }
    }
}
