package com.hcl.admin.services;

import java.util.Random;

import com.hcl.admin.beans.Employee;
//OR could use interface as part of ABSTRACT OOPs concept
public interface CredentialService {
    //all methods are abstract
    public void generateEmail(String dept, Employee emp);
    public void generatePassword(Employee emp);
    public String showCredentials(Employee emp);
}
//
// public class CredentialService {
//     final String ALPHA_CAPITAL = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
//     final String ALPHA_SMALL = "abcdefghijklmnopqrstuvwxyz";
//     final String SPECIAL_CHAR = "!@#$%^&*()_";

//     public void generateEmail(String dept, Employee emp){
//         String usrname = emp.getUsername();
//         String deptStr = "";
//         String domain = "@hcl.com";
//         switch(dept){
//             case "1":
//             deptStr = "tech";
//             break;
//             case "2":
//             deptStr = "admin";
//             break;
//             case "3":
//             deptStr = "marketing";
//             break;
//         }
//         emp.setUserEmail(usrname+"."+deptStr+domain);
//     }

//     public void generatePassword(Employee emp){
//         String randPwd = "";
//         Random rand =  new Random();
//         String randNum =  rand.nextInt(9) + "";
//          //(int) (Math.random() * ALPHA_CAPITAL.length());
//         String alphaCapital = ALPHA_CAPITAL.charAt(rand.nextInt(ALPHA_CAPITAL.length())) +"";
//         String alphaSmall = ALPHA_SMALL.charAt(rand.nextInt(ALPHA_SMALL.length())) +"";
//         String randChar = SPECIAL_CHAR.charAt(rand.nextInt(SPECIAL_CHAR.length())) +"";
//         randPwd += randNum+alphaCapital+alphaSmall+randChar;
//         System.out.println("randPwd"+randPwd);
//         emp.setUserPwd(randPwd);
//     }

//     public String showCredentials(Employee emp){
//         return "----------Credentials------------- \r\n Email: "+emp.getUserEmail()+"\r\n Password: "+emp.getUserPwd()
//         +"\r\n Generated employee creds for today: "+ Employee.empyCount;
//     }
// }
