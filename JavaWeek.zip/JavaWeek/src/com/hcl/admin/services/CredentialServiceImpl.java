package com.hcl.admin.services;

import java.util.Random;

import com.hcl.admin.beans.Employee;

public class CredentialServiceImpl implements CredentialService{
    final String ALPHA_CAPITAL = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    final String ALPHA_SMALL = "abcdefghijklmnopqrstuvwxyz";
    final String SPECIAL_CHAR = "!@#$%^&*()_";

    @Override
    public void generateEmail(String dept, Employee emp) {
        // TODO Auto-generated method stub
        String usrname = emp.getUsername();
        String deptStr = "";
        String domain = "@hcl.com";
        switch(dept){
            case "1":
            deptStr = "tech";
            break;
            case "2":
            deptStr = "admin";
            break;
            case "3":
            deptStr = "marketing";
            break;
        }
        emp.setUserEmail(usrname+"."+deptStr+domain);        
    }

    @Override
    public void generatePassword(Employee emp) {
        //make sure min 1 capital, 1 small, 1 number, 1 char
        String randPwd = "";
        Random rand =  new Random();
        String randNum =  rand.nextInt(9) + "";
        String alphaCapital = ALPHA_CAPITAL.charAt(rand.nextInt(ALPHA_CAPITAL.length())) +"";
        String alphaSmall = ALPHA_SMALL.charAt(rand.nextInt(ALPHA_SMALL.length())) +"";
        String randChar = SPECIAL_CHAR.charAt(rand.nextInt(SPECIAL_CHAR.length())) +"";
        randPwd += randNum+alphaCapital+alphaSmall+randChar;
        //make sure min pwd length is 8
        String aplhaNumChar = ALPHA_CAPITAL+ALPHA_SMALL+SPECIAL_CHAR+"0123456789";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i <= 4; i++) {
            int index = (int)(aplhaNumChar.length()* Math.random());
            sb.append(aplhaNumChar.charAt(index));
        }
        randPwd += sb.toString();
        emp.setUserPwd(randPwd);        
    }

    @Override
    public String showCredentials(Employee emp) {
        // TODO Auto-generated method stub
        return "----------Credentials------------- \r\n Email: "+emp.getUserEmail()+"\r\n Password: "+emp.getUserPwd()
        +"\r\n Generated employee creds for today: "+ Employee.empyCount;
    }
    
}
