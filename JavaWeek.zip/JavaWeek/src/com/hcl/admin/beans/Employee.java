package com.hcl.admin.beans;

public class Employee {
    private String firstNane;
    private String lastName;
    private String username;
    private String userEmail;
    private String userPwd;
    private String userDept;
    public static int empyCount;

    //parametized constructor
    public Employee(String fName, String lName, String dept){
        this.firstNane = fName;
        this.lastName = lName;
        this.username = fName+"_"+lName;
        this.userDept = dept;
        Employee.empyCount++;
    }

    /**
     * @return String return the userEmail
     */
    public String getUserEmail() {
        return userEmail;
    }

    /**
     * @param userEmail the userEmail to set
     */
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    /**
     * @return String return the userPwd
     */
    public String getUserPwd() {
        return userPwd;
    }

    /**
     * @param userPwd the userPwd to set
     */
    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }

    /**
     * @return String return the firstNane
     */
    public String getFirstNane() {
        return firstNane;
    }

    /**
     * @param firstNane the firstNane to set
     */
    public void setFirstNane(String firstNane) {
        this.firstNane = firstNane;
    }

    /**
     * @return String return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }


    /**
     * @return String return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }



    /**
     * @return String return the userDept
     */
    public String getUserDept() {
        return userDept;
    }

    /**
     * @param userDept the userDept to set
     */
    public void setUserDept(String userDept) {
        this.userDept = userDept;
    }

    @Override
    public String toString() {
        return "{" +
            " firstNane='" + getFirstNane() + "'" +
            ", lastName='" + getLastName() + "'" +
            ", username='" + getUsername() + "'" +
            ", userEmail='" + getUserEmail() + "'" +
            ", userPwd='" + getUserPwd() + "'" +
            ", userDept='" + getUserDept() + "'" +
            "}";
    }


}
