package com.hcl.admin;

import java.util.Scanner;

import com.hcl.admin.beans.Employee;
import com.hcl.admin.services.CredentialService;
import com.hcl.admin.services.CredentialServiceImpl;

public class demo {
    public static void main(String[] args){

        Scanner scan = new Scanner(System.in);

        int choice = 0;
        while(choice != 2){
            System.out.println("-----1: New Credetials | 2: Logout-----");
            System.out.print("Please input here: ");
            choice = scan.nextInt();
            switch(choice){
                case 1:
                    System.out.print("Please input first name: ");
                    String fName = scan.next();
                    System.out.print("Please input last name: ");
                    String lName = scan.next();
                    System.out.print("Select Department 1: Tech | 2: Admin | 3: Marketing - ");
                    String dept = scan.next();
                    Employee emp = new Employee(fName,lName,dept);
                    System.out.println("Employee Obj"+ emp);
                    // CredentialService serv = new CredentialService(); //normal way
                    CredentialService serv = new CredentialServiceImpl(); //interface way
                    serv.generateEmail(dept, emp);
                    serv.generatePassword(emp);
                    System.out.println(serv.showCredentials(emp));
                    break;
                case 2:
                    System.out.println("logging out...");
                    scan.close();
                    break;

            }
        }
    }
}
