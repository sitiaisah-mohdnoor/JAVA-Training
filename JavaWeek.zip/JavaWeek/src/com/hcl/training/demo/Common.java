package com.hcl.training.demo;

public interface Common {
    public String markAttendance();
    public String dailyTask();
    public String displayDetails();
}
