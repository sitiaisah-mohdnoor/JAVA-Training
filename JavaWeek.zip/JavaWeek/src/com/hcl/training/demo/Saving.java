package com.hcl.training.demo;

public class Saving {
    //encapsulation example
    private int accNo = 800234554;

    /**
     * @return int return the accNo
     */
    public int getAccNo() {
        return accNo;
    }

    /**
     * @param accNo the accNo to set
     */
    public void setAccNo(int accNo) {
        this.accNo = accNo;
    }

}
