package com.hcl.training.demo;

//use 'extends' for inheritence
//can access methods from parent or superclass
public class Sofa  extends Furniture{
    public void intro() {
        System.out.println("Sofa is child of Furniture ");
    }
}
