package com.hcl.training.demo;

public class Manager implements Common{
    @Override
    public String markAttendance(){
        return "Attendance marked for today";
    }

    @Override
    public String dailyTask(){
        return "Create project architecture";
    }

    @Override
    public String displayDetails(){
        return "Manager details";
    }
}
