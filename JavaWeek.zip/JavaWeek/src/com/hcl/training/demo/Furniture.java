package com.hcl.training.demo;

public class Furniture {
    /**
     * if variables, constructors, methods dont have access mods
     * it will become 'default' - accessible inside own package only
     * 
     */

    // instance variables
    // gets allocated in memory heap
    double price;
    int quantity;
    // class variable
    // use to track how many Furniture obj getting created
    static int count;

    /**
     * dont have to create constructor, below just examples
     */

    // default constructor
    // created upon compilation unless u have created parametized constructor
    Furniture() {
        // initialize variables
        System.out.println("default");
        count++;
    }

    // parametized constructor
    Furniture(int qty) {
        // initialize variables
        this.quantity = qty;
        count++;
    }

    // becomes constructor overload when there's multiple constructor
    Furniture(int qty, double price) {
        // initialize variables
        this.quantity = qty;
        count++;
    }

    public int calcPrice() {
        return (int) (price * quantity);
    }

    public void printStatus() {
        System.out.println("Furniture obj count: " + count);
    }

    public void intro() {
        System.out.println("Furniture is parent ");
    }
}
