package com.hcl.training.demo;

public class Employee implements Common{
    @Override
    public String markAttendance(){
        return "Attendance marked for today";
    }

    @Override
    public String dailyTask(){
        return "Complete coding of module 1";
    }

    @Override
    public String displayDetails(){
        return "Employee details";
    }
}
