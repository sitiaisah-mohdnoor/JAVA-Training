package com.hcl.training.demo;

//to resolve error abstract class cant be instatiated
// class KTM extends Bike{
//     void run (){
//         System.out.println("ktm run");
//     }
// }

// class Pulsar extends Bike{
//     void run (){
//         System.out.println("pulsar run");
//     }
// }

//abstract public class Bike {
//     //becomes abstract class if contain more than 1 abstract method
//     abstract void run();
// }

//interface example
//abstract by default
//no need abstract and class keywird
// interface Bike {
//      void run();
// }

// class Two {
//     public void talk(){
//         System.out.println("talk");
//     }
// }

// //must use implements and set methid to public
// class KTM implements Bike{
//     public void run (){
//         System.out.println("ktm run interface type");
//     }
// }

// public class Bike{
//     public static void main(String[] args) {
//         A obj = new A();
//         obj.display();
//     }
// }

// class A{
//     private void display(){
//         System.err.println("hell");
//     }
// }