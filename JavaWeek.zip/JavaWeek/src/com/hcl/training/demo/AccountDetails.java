package com.hcl.training.demo;

public class AccountDetails extends CurrentAccount{
    int depositAmount;
    int withdrawalAmount;
    public AccountDetails(String a, int b, int c, int d, int e) {
        super(a,b,c); //to access CurrentAccount constructor
        this.depositAmount = d;
        this.withdrawalAmount = e;
    }

    public void display() throws Exception{
        super.display();
        // System.out.println("customerName: "+super.customerName+
        // " \r\n accountNo: "+super.accountNo+
        // " \r\n currentBalance: "+super.currentBalance+
        // " \r\n depositAmount: "+this.depositAmount+
        // " \r\n withdrawalAmount: "+this.withdrawalAmount);
        System.out.println(
        "depositAmount: "+this.depositAmount+
        "\n"+"withdrawalAmount: "+this.withdrawalAmount);
    }
}
