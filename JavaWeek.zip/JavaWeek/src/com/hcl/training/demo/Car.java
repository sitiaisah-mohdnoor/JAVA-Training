package com.hcl.training.demo;

public class Car {

    //instance variables or attributes;belongs to instance of object
    String brand;
    String model;
    String color;
    double price;
    int quantity;
    //class vars or attributes; will be share among all object of this class
    static int carSales;
    static int totalSales;

    //use default constructor

    //methods
    public void printReceipt(String brand, String model, String color, double price, int qty){
        carSales += qty;
        totalSales += (price * qty);
        System.out.println("--------Receipt--------");
        System.out.println("brand: "+ brand);
        System.out.println("model: "+ model);
        System.out.println("color : "+ color);
        System.out.println("price: "+ price);
        System.out.println("qty: "+ qty);
        System.out.println("total: "+ (price * qty));
        System.out.println("car sold today: "+ carSales);
        System.out.println("total sales today: "+ totalSales);
        System.out.println("---------End---------");
    }

}
