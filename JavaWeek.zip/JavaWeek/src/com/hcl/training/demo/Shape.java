package com.hcl.training.demo;

public class Shape {
    //compile time or overload poly

    public double calcArea(int a){
        return a*a;
    }
    public double calcArea(int a, int b){
        return a*b;
    }
    public double calcArea(double a){
        return 3.14*a*a;
    }
}
