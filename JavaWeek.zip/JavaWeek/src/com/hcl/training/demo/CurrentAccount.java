package com.hcl.training.demo;

public class CurrentAccount extends Account{
    int currentBalance;

    public CurrentAccount(String a, int b, int c) {
        super(a,b); //to access Account constructor
        this.currentBalance = c;
    }

    public void display() throws Exception{
        super.display();
        // System.out.println("customerName: "+super.customerName+" \r\n accountNo: "+super.accountNo+" \r\n currentBalance: "+this.currentBalance);
        System.out.println("currentBalance: "+this.currentBalance);
    }

}
