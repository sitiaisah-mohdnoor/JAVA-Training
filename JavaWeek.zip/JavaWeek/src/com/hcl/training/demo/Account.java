package com.hcl.training.demo;
//super class
public class Account {
    String customerName;
    int accountNo;

    public Account(String a, int b) {
        this.customerName = a;
        this.accountNo = b;
    }

    public void display() throws Exception{
        System.out.println("customerName: "+this.customerName+"\n"+"accountNo: "+this.accountNo);
    }
}
