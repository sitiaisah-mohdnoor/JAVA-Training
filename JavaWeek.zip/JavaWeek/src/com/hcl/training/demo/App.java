package com.hcl.training.demo;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
public class App {
//'main' method is the entry point

static int i;
private static void show(){
    System.out.println("show()");
}

    public static void main(String[] args) throws Exception {
    
        // show();
        // int b1 = 80;
        // int b2 = 100;
        // int b3;
        // b3 = ++b1 * b1/100 + ++b2;
        // System.err.println(b3);

        // int[][] arr = {{},{}};

        // boolean b2 = (4 != 4) || (4 ==4);
        // System.out.println(b2);
        // while(i < 0){
        //     i--;
        // }
        // System.out.println(i);

        // StringBuffer str = new StringBuffer("APPLE");
        // str.setCharAt(3, 'X');
        // System.out.println(str);

        // int i = 100;
        // if(((i++) > 102) && (++i < 105))
        //     System.out.println(i);
        // else
        //     System.out.println(i);
      
        int a = 129;
        byte b = (byte) a;
        System.out.println("byte" +b);


        // System.out.println("main thread start");
        // MyThread thr1 = new MyThread();
        // MyThread thr2 = new MyThread();

        // Thread th1 = new Thread(thr1, "thread1");
        // Thread th2 = new Thread(thr2, "thread2");

        // th1.start();
        // try {
        //     System.out.println("wait t1 to finish b4 cont to t2");
        //     th1.join();  //wait for finish until cont to next thread
        // } catch (InterruptedException e) {
        //     e.printStackTrace();
        // }
        // th2.start(); 
        // System.out.println("main thread end");







        // Furniture furObj = new Furniture(); //object creation
        // furObj.price = 50.5;
        // furObj.quantity = 2;
        // System.out.println(Furniture.count); //how to access class variable
        // System.out.println(furObj.calcPrice());
        // furObj.printStatus();

        //nested try
        // try {//block1
        //     try {//block2
        //         try {//block3
        //             int arr[] = {1,2,3,4};
        //             System.out.println(arr[10]);
                    
        //         } catch (NullPointerException e) {
        //             System.out.println("NullPointerException in block3");
        //            //throw e;
        //         }
        //     } catch (StringIndexOutOfBoundsException e) {
        //         System.out.println("StringIndexOutOfBoundsException in block2");
        //         //throw e;
        //     }
        // } catch (ArrayIndexOutOfBoundsException e) {
        //     System.out.println("ArrayIndexOutOfBoundsException in block1");
        // }

        //overload poly
        // Shape shapey = new Shape();
        // System.out.println("area: "+ shapey.calcArea(3));
        // System.out.println("area: "+ shapey.calcArea(3,7));
        // System.out.println("area: "+ shapey.calcArea(3.5));

        // //overide poly
        // //which method gets called depends on the object
        // Sofa sofay = new Sofa();
        // sofay.intro();

        // //encapsulation example
        // Saving save = new Saving();
        // save.setAccNo(4234234);
        // System.out.println(save.getAccNo()); 

        // //abstraction
        // //will get error Bike is abstract, cant be instantiated
        // //Bike ktm = new Bike(); 
        // Bike ktm = new KTM(); 
        // ktm.run();


        // //interface example, lab D4Q1
        // Employee emp = new Employee();
        // System.out.println(emp.dailyTask());
        // System.out.println(emp.markAttendance());
        // System.out.println(emp.displayDetails());
        // Manager manager = new Manager();
        // System.out.println(manager.markAttendance());
        // System.out.println(manager.dailyTask());
        // System.out.println(manager.displayDetails());

        //D4Q2
        // AccountDetails accDtls = new AccountDetails("siti", 12345, 5000, 500, 300);
        // accDtls.display();

        // while(true){
        //     Car carObj = new Car();
        //     Scanner scan = new Scanner(System.in);
        //     System.out.println("brand?");
        //     String brand = scan.next();
        //     System.out.println("model?");
        //     String model = scan.next();
        //     System.out.println("color?");
        //     String color = scan.next();
        //     System.out.println("price?");
        //     double price = scan.nextDouble();
        //     System.out.println("quantity?");
        //     int qty = scan.nextInt();
        //     carObj.printReceipt(brand, model, color, price, qty);           
        // }
    }

    //user defined annotations
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface PrintMethod{ //use public so it can be use anywhere
        //this is a marker annotation
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.FIELD)
    public @interface JsonElement {
        //when annots have method; must have no parameter and cannot throw exception, default value cant be null
        public String key() default "";
    }
}

//application terminated here