package com.hcl.training.lab;

import java.util.ArrayDeque;
import java.util.Deque;

public class DequeImpl {
    public static void main(String[] args) {
        Deque<Integer> dq = new ArrayDeque<>();
        dq.add(4);
        dq.add(1);
        dq.add(8);
        dq.add(0);
        dq.add(6);
        System.out.println("dq elm: "+dq);
        dq.addFirst(7);
        System.out.println("dq elm: "+dq);
        dq.addLast(3);
        System.out.println("dq elm: "+dq);
        System.out.println("peek first elm: "+ dq.peekFirst());
        dq.removeAll(dq);
        System.out.println("size: "+dq.size());
    }
}
