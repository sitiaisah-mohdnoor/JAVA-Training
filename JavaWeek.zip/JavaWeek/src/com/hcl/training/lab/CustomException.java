package com.hcl.training.lab;

public class CustomException extends Exception{
    
    public CustomException(String msg){
        super(msg);
    }
}
