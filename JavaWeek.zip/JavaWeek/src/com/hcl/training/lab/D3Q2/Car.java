package com.hcl.training.lab.D3Q2;

public class Car extends Vehicle{
    public void noOfWheels(){
        System.out.println("no of wheels car 4");
    }
}
