package com.hcl.training.lab.D3Q2;

public class Scooter extends Vehicle{
    
    public void noOfWheels(){
        System.out.println("no of wheels scooter 2");
    }
}
