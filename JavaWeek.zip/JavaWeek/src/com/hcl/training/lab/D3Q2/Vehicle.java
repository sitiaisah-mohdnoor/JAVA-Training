package com.hcl.training.lab.D3Q2;
/**
 * poly override example
 */
public class Vehicle {
    public static void main(String[] args) throws Exception {
        Vehicle vehicle = new Vehicle();  // Create a Vehicle object

        Vehicle scooter = new Scooter();  // Create a Scooter object
      
        Vehicle car = new Car();  // Create a Car object
      
                    vehicle.noOfWheels();     //call noOfWheels of vehicle class
      
                    scooter.noOfWheels();   //call noOfWheels of Scooter class
      
                    car.noOfWheels();         // call noOfWheels of Car class
    }

    public void noOfWheels(){
        System.out.println("no of wheels vehicle");
    }
}
