package com.hcl.training.lab;

import java.util.HashMap;
import java.util.Map;

import javax.xml.crypto.dsig.spec.HMACParameterSpec;

public class HashMapImpl {
    public static void main(String[] args) {
        HashMap<String, String> hm = new HashMap<>();
        hm.put("England", "London");
        hm.put("Germany", "Berlin");
        hm.put("Norway", "Oslo");
        hm.put("USA", "Washington DC");
        System.out.println("hashCode " +hm.hashCode());
        System.out.println("size " +hm.size());
        System.out.println("hashmap " + hm);       
        System.out.println("key present " + hm.get("Germany"));  
        System.out.println("values only " + hm.values());  
        System.out.println("certain val " + hm.containsValue("London"));
        System.out.println("keyset " + hm.keySet());
        hm.remove("USA");
        System.out.println("after remove " + hm);
        //Map.Entry stores both the key and value together in one class, we get them both in a single operation.
        for(Map.Entry<String,String> city: hm.entrySet()){
            System.out.println("key: " + city.getKey() + " value: " + city.getValue());
        }

    }
}
