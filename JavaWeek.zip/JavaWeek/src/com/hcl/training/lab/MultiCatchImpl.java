package com.hcl.training.lab;

import java.util.Scanner;

public class MultiCatchImpl {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int[] arr = {4,6,7,3,1};
        while(true){
            try {
                System.out.print("please input random index: ");
                int idx = scan.nextInt();
                System.out.println("element of index "+idx+" is :"+ arr[idx]);
                System.out.print("please input divider: ");
                int divider = scan.nextInt();
                int res = arr[idx]/divider;
                System.out.println("result "+ res);
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("ArrayIndexOutOfBoundsException"+e);
            } catch (ArithmeticException e) {
                System.out.println("ArithmeticException"+e);
            } catch (Exception e) {
                System.out.println("Exception"+e);
            }
        }
    }
}
