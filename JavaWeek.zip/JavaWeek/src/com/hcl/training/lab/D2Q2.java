package com.hcl.training.lab;

public class D2Q2 {
    public static void main(String[] args) throws Exception {
        printStar(5);
    }

    static void printStar(int num) {
        for(int i = 1; i <= num; i++){
            // System.out.println("*".repeat(i));
            for(int j = 1; j <= i; j++){
                System.out.print('*');
            }
            System.out.println();
        }
    }
}
