package com.hcl.training.lab;

import java.util.Scanner;

public class D3Q1 {
    public static void main(String[] args) {
        while(true){
            System.out.print("Input: ");
            Scanner scan = new Scanner(System.in);
            int ipt = scan.nextInt();
            int cnt = 1;
            while(cnt <= 10){
                System.out.println(printTable(ipt, cnt));
                cnt++;
            }
        }
    }

    static int printTable(int num, int multi){
        return num*multi;
    }
}
