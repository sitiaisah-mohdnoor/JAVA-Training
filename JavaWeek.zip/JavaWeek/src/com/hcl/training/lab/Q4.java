package com.hcl.training.lab;

import java.util.Scanner;

public class Q4 {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        while(true){
            System.out.println("Please input year");
            int intInput = scan.nextInt();
            System.out.println(checkLeapYear(intInput));
        }
        // scan.close();
        // if((intInput % 400 == 0) || (intInput % 4 == 0 && intInput % 100 != 0)){
        // System.out.println("leap year");
        // }else{
        // System.out.println("not leap year");
        // }
    }

    static String checkLeapYear(int a) {
        if((a % 400 == 0) || (a % 4 == 0 && a % 100 != 0)){
        return ("leap year");
        }else{
        return ("not leap year");
        }
    }
}
