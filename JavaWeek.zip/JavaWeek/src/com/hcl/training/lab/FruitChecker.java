package com.hcl.training.lab;

import java.util.ArrayList;

public class FruitChecker{

    public ArrayList<String> checkFruit(String fruit, ArrayList<String> fruitList) throws CustomException{
        if(!fruitList.contains(fruit)){
            fruitList.add(fruit);
        }else{
            throw new CustomException(fruit + " already exist.");
        }
        return fruitList;
    }
}
