package com.hcl.training.lab;



public class D2Q1 {
    public static void main(String[] args) throws Exception {
        int num = 10;
        printDownward(num);
    }

    static void printDownward(int num) {
        while(num != 0){
            System.out.println(num);
            num--;
        }

    }
}
