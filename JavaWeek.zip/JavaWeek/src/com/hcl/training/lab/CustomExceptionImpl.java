package com.hcl.training.lab;

import java.util.ArrayList;
import java.util.Scanner;

public class CustomExceptionImpl {
    public static void main(String[] args) {
        ArrayList<String> arrList = new ArrayList<>();
        FruitChecker checker = new FruitChecker();
        Scanner scan = new Scanner(System.in);
        while(true){
            System.out.print("Add fruit: ");
            String item = scan.next();
            try {
                System.out.println("update list: "+checker.checkFruit(item, arrList));               
            } catch (CustomException e) {
                e.printStackTrace();
                System.out.println(e);
            }
        }
    }
}
