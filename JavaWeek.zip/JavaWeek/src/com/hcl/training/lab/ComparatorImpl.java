package com.hcl.training.lab;

import java.util.Collections;
import java.util.Comparator;
import java.util.PriorityQueue;

public class ComparatorImpl {
    public static void main(String[] args) {
        int initialCapacity = 10;
        Comparator<String> scomp = new StringCompare();
        PriorityQueue<String> pq = new PriorityQueue<String>(initialCapacity, scomp);
        pq.add("helloooooos");
        pq.add("multiple");
        pq.add("armour");
        pq.add("zebra");
        pq.add("I");
        System.out.println("Unsorted "+ pq);
        // Collections.sort(pq, scomp);
        while (pq.size() != 0) {
            System.out.println(pq.remove());
        }
    }
}


class StringCompare implements Comparator<String>{

    @Override
    public int compare(String o1, String o2) {
        //return o1.compareTo(o2); //sort alphabetically
        return o1.length() - o2.length(); //sort by length
        //OR
        // if (o1.length() < o2.length()) {
        //     return -1;
        // } else if(o1.length() > o2.length()){
        //     return 1;
        // }
        // return 0;
    }
}