package com.hcl.training.lab;

import java.util.Scanner;

public class D2Q3 {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        System.out.println("1st input");
        String input1 = scan.next();
        System.out.println("2nd input");
        String input2 = scan.next();
        scan.close();
        System.out.println(compareString(input1, input2));
    }

    static String compareString(String a, String b){
        return a.equals(b)? "equal":"not equal";
    }
}
