package com.hcl.training.lab;

import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        System.out.println("Please input number");
        int intInput = scan.nextInt();
        scan.close();
        System.out.println(checkEvenNumber(intInput));
        // if(intInput % 2 == 0){
        //     System.out.println("Number is even");
        // }else{
        //     System.out.println("Number is odd");
        // }
    }

    static String checkEvenNumber(int a){
        if(a % 2 == 0){
            return ("Number is even");
        }else{
            return ("Number is odd");
        }
    }
}
