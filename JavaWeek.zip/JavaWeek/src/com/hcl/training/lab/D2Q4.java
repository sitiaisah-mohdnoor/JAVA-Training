package com.hcl.training.lab;

import java.util.Scanner;

public class D2Q4 {
    public static void main(String[] args) throws Exception {
        while(true){
            Scanner scan = new Scanner(System.in);
            System.out.println("Enter the size of array :");
            int arrSize = scan.nextInt();
            int counter = 0;
            int[] arrItem = new int [arrSize];
            while(counter < arrSize){
                System.out.println("Enter elements of array :");
                int item = scan.nextInt();
                arrItem[counter] = item;
                counter++;
            }
            int cnt = 0; 
            int sumEven = 0;
            int sumOdd = 0;
            for(int el:arrItem){
                if(cnt%2 == 0){
                    sumEven += el;
                }else{
                    sumOdd += el;
                }
                cnt++;
            }
            System.out.println("Sum of even index nos  is " + sumEven);
            System.out.println("Sum of even index nos  is " + sumOdd);
        }
    }

    static void calcSum(){
        
    }
}
