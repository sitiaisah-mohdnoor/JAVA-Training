package com.hcl.training.lab;

public class Q1 {
    public static void main(String[] args) throws Exception {
        System.out.println("My first Program in Java");
    }
}
