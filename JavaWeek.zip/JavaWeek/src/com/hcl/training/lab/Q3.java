package com.hcl.training.lab;

import java.util.Scanner;

public class Q3 {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        System.out.println("Please input number");
        int intInput = scan.nextInt();
        scan.close();
        // String strOutput = (intInput % 2 == 0)? "Number is even" : "Number is odd";
        System.out.println(checkEvenNumber(intInput));
    }
    static String checkEvenNumber(int a){
        String strOutput = (a % 2 == 0)? "Number is even" : "Number is odd";
        return strOutput;
    }
}
