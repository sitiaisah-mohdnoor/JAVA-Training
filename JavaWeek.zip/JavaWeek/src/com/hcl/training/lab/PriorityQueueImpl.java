package com.hcl.training.lab;

import java.util.PriorityQueue;

public class PriorityQueueImpl {
    public static void main(String[] args) {
        PriorityQueue<Integer> que = new PriorityQueue<>();
        que.add(5);
        que.add(1);
        que.add(3);
        que.add(8);
        que.add(2);
        System.out.println("head of element: " +que.peek()); 
        System.out.println("contain certain element: " +que.contains(8)); 
        System.out.println("size of queue: " + que.size());
        que.remove(3);
        System.out.println("element '3' deleted: " + que);
        que.removeAll(que);
        System.out.println("all elm removed: " + que);
        System.out.println(que.size() > 1? "not empty":"que empty" );
    }
}
