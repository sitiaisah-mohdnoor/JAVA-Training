package com.hcl.training.lab;

import java.util.Scanner;

public class NestedTryImpl {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int count = 0;
        System.out.print("please input array size: ");
        int size = scan.nextInt();
        int[] arr = new int[size];
        while(count < arr.length){
            System.out.print("please input array elm: ");
            arr[count] = scan.nextInt();
            count++;
        }
        while(true){
            System.out.print("please input random index: ");
            int idx = scan.nextInt();
            try {
                System.out.println("element of index "+idx+" is :"+ arr[idx]);
                try {
                    System.out.print("please input divider: ");
                    int divider = scan.nextInt();
                    int res = arr[idx]/divider;
                    System.out.println("result "+ res);
                } catch (ArithmeticException  e) {
                    System.out.println("ArithmeticException " + e);
                }
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("ArrayIndexOutOfBoundsException" + e);
            }
        }
    }
}
