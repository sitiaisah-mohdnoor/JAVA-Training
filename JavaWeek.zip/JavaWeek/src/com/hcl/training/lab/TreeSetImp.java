package com.hcl.training.lab;

import java.util.TreeSet;
import java.util.Iterator;
public class TreeSetImp {
    public static void main(String[] args) {
        TreeSet<Integer> tr = new TreeSet<>();
        tr.add(4);
        tr.add(1);
        tr.add(8);
        tr.add(0);
        tr.add(6);
        System.out.println("tr elm: "+tr);
        Iterator<Integer> it = tr.iterator();
        while(it.hasNext()){
            System.out.print(it.next()+ " ");
        }
        System.out.println();
        System.out.println("1st elm: "+tr.first());
        System.out.println("last elm: "+tr.last());
        tr.remove(tr.last());
        System.out.println("tr updated: "+tr);
        System.out.println("tr size: "+tr.size());
    }
}
