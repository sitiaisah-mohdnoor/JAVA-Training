package com.hcl.foodapp;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.hcl.foodapp.beans.Address;
import com.hcl.foodapp.beans.Admin;
import com.hcl.foodapp.beans.Restaurant;
import com.hcl.foodapp.services.AdminServiceImpl;
import com.hcl.foodapp.services.IAdminService;
import com.hcl.foodapp.services.IRestaurantService;
import com.hcl.foodapp.services.RestaurantServiceImpl;

public class Demo {
    static Restaurant currentRestaurant = null;
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        IAdminService adminServ = new AdminServiceImpl();
        IRestaurantService resServ = new RestaurantServiceImpl();
        mainSelection(scan, adminServ, resServ);
    }

    static void mainSelection(Scanner scan, IAdminService adminServ, IRestaurantService resServ){
        int select = 0;
        while(select != 2){
            System.out.println("-----1: Admin | 2: Restaurant | 3: Customer-----");
            System.out.print("Please input here: ");
            //to handle inputMismatchExp
            while(!scan.hasNextInt()){
                System.out.println("input not a number!");
                scan.next();// important else infinite loop
                System.out.println("-----1: Admin | 2: Restaurant | 3: Customer-----");
            }
            select = scan.nextInt();
            switch(select){
                case 1:
                    //default Admin credential
                    Admin admin = new Admin("admin@gmail.com", "@dm1n");
                    System.out.print("Admin username: ");
                    String usr = scan.next();
                    System.out.print("Admin Password: ");
                    String pwd = scan.next();
                    System.out.println("login as admin "+adminServ.authenticateAdmin(usr,pwd,admin));
                    adminSelection(scan, adminServ, resServ);
                    break;
                case 2:
                    System.out.println("-----1: Existing Restaurant | 2: New Restaurant-----");
                    //to handle inputMismatchExp
                    while(!scan.hasNextInt()){
                        System.out.println("input not a number!");
                        scan.next();// important else infinite loop
                        System.out.println("-----1: Existing Restaurant | 2: New Restaurant-----");
                    }
                    select = scan.nextInt();
                    if(select == 1){
                        List<Restaurant> allRes = new ArrayList<>();
                        allRes = resServ.getActiverestaurant();
                        System.out.println("active restaurant: " + allRes);
                        if(allRes.size() > 0){
                            while(currentRestaurant == null){
                                System.out.print("Username: ");
                                String resUsr = scan.next();
                                System.out.print("Password: ");
                                String resPwd = scan.next();
                                System.out.println("Authenticating....");
                                currentRestaurant = resServ.authenticateLogin(resUsr, resPwd);
                                if(currentRestaurant != null) {
                                    System.out.println("successfull"); 
                                    RestaurantSelection(scan, adminServ, resServ);
                                    break;
                                }
                                else System.out.println("failed");
                            }
                        }
                    }else{
                        //TODO: enhance to user input later
                        Address resAddress = new Address("Unit-10", "Flower Street", "Taiping", "perak", "34000");
                        Restaurant newRes = new Restaurant("res1@gmail.com", "res@1", "KFC", resAddress, "012333333", false);
                        Address resAddress2 = new Address("Unit-11", "Vege Street", "Taiping", "perak", "34000");
                        Restaurant newRes2 = new Restaurant("res2@gmail.com", "res@2", "MCD", resAddress2, "012444444", false);
                        resServ.createRestaurant(newRes);
                        resServ.createRestaurant(newRes2);
                        System.out.println("Creating Restaurants.......");
                        //TODO: enhance looping later
                        adminSelection(scan, adminServ, resServ);
                    }
                    break;
                case 3:
                    customerSelection(scan, adminServ, resServ);
                    break;

            }
        }
    }

    static void adminSelection(Scanner scan, IAdminService adminServ, IRestaurantService resServ){
        int choice = 0;
        while(true){
            System.out.println("-----1: Active Restaurant | 2: Approve Restaurant | 3: Logout-----");
            System.out.print("Please input here: ");
             //to handle inputMismatchExp
            while(!scan.hasNextInt()){
                System.out.println("input not a number!");
                scan.next();// important else infinite loop
                System.out.println("-----1: Active Restaurant | 2: Approve Restaurant | 3: Logout-----");
            }
            choice = scan.nextInt();
            if(choice > 0 && choice < 6){
                switch(choice){
                    case 1:
                        System.out.println("Active :"+ resServ.getActiverestaurant());                      
                        break;
                    case 2:
                        System.out.println("Pending :"+ resServ.getPendingrestaurant());
                        System.out.print("Select restaurant index for approval: ");
                        int idx = scan.nextInt();
                        resServ.approveRestaurant(resServ.getPendingrestaurant().get(idx));
                        // System.out.println("Active: "+ resServ.getActiverestaurant());
                        break;
                    case 3:
                        System.out.println("logging out...");
                        mainSelection(scan, adminServ, resServ);
                        break;

                }
            }else{
                System.out.println("Invalid input range");
            }
        }
    }

    static void RestaurantSelection(Scanner scan, IAdminService adminServ, IRestaurantService resServ){
            int choice = 0;
            while(true){
                System.out.println("-----1: Add Menu 5: Logout-----");
                System.out.print("Please input here: ");
                 //to handle inputMismatchExp
                while(!scan.hasNextInt()){
                    System.out.println("input not a number!");
                    scan.next();// important else infinite loop
                    System.out.println("-----1: Add Menu | 5: Logout-----");
                }
                choice = scan.nextInt();
                if(choice > 0 && choice < 6){
                    switch(choice){
                        case 1:
                            // TODO enhance to user input later
                            System.out.println("Adding menu......");
                            System.out.println(resServ.addMenu(currentRestaurant));
                            break;
                        case 2:

                            break;
                        case 3:
     
                            break;
                        case 4:
                            break;
                        case 5:
                            System.out.println("logging out...");
                            mainSelection(scan, adminServ, resServ);
                            break;

                    }
                }else{
                    System.out.println("Invalid input range");
                }
            }
    }

    static void customerSelection(Scanner scan, IAdminService adminServ, IRestaurantService resServ){
        int choice = 0;
        while(true){
            System.out.println("-----1: See Menu 5: Logout-----");
            System.out.print("Please input here: ");
             //to handle inputMismatchExp
            while(!scan.hasNextInt()){
                System.out.println("input not a number!");
                scan.next();// important else infinite loop
                System.out.println("-----1: See Menu | 5: Logout-----");
            }
            choice = scan.nextInt();
            if(choice > 0 && choice < 6){
                switch(choice){
                    case 1:
                        // TODO enhance to user input later
                        System.out.println(resServ.menuList(currentRestaurant));
                        break;
                    case 2:

                        break;
                    case 3:
 
                        break;
                    case 4:
                        break;
                    case 5:
                        System.out.println("logging out...");
                        mainSelection(scan, adminServ, resServ);
                        break;

                }
            }else{
                System.out.println("Invalid input range");
            }
        }
    }
}
