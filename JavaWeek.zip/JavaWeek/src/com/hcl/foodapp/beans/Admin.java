package com.hcl.foodapp.beans;
/**
 * Manage application -- approve,reject,delete restaurants
 */
public class Admin {
    private String adminEmail;
    private String adminPwd;

    public Admin(String adminEmail, String adminPwd) {
        this.adminEmail = adminEmail;
        this.adminPwd = adminPwd;
    }

    /**
     * @return String return the adminEmail
     */
    public String getAdminEmail() {
        return adminEmail;
    }

    /**
     * @param adminEmail the adminEmail to set
     */
    public void setAdminEmail(String adminEmail) {
        this.adminEmail = adminEmail;
    }

    /**
     * @return String return the adminPwd
     */
    public String getAdminPwd() {
        return adminPwd;
    }

    /**
     * @param adminPwd the adminPwd to set
     */
    public void setAdminPwd(String adminPwd) {
        this.adminPwd = adminPwd;
    }

}
