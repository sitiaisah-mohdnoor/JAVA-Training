package com.hcl.foodapp.beans;

import java.util.ArrayList;
import java.util.List;

public class Restaurant {
	private String resId;
    private String resPwd;
	private String name;
	private Address restaurantAddress;
	private String restaurantContact;
    private boolean approved;
    private List<Menu> foodList = new ArrayList<>();
    private List<Restaurant> allRestaurant = new ArrayList<>();

    public Restaurant(){

    }

    public Restaurant(String resId, String resPwd, String name, Address restaurantAddress, String restaurantContact, boolean approved) {
        this.resId = resId;
        this.resPwd = resPwd;
        this.name = name;
        this.restaurantAddress = restaurantAddress;
        this.restaurantContact = restaurantContact;
        this.approved = approved;
    }

    @Override
    public String toString() {
        return "{" +
            " resId='" + getResId() + "'" +
            ", resPwd='" + getResPwd() + "'" +
            ", name='" + getName() + "'" +
            ", restaurantAddress='" + getRestaurantAddress() + "'" +
            ", restaurantContact='" + getRestaurantContact() + "'" +
            ", approved='" + isApproved() + "'" +
            ", foodList='" + getFoodList() + "'" +
            ", restaurantList='" + getAllRestaurant() + "'" +
            "}";
    }

    /**
     * @return String return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return Address return the restaurantAddress
     */
    public Address getRestaurantAddress() {
        return restaurantAddress;
    }

    /**
     * @param restaurantAddress the restaurantAddress to set
     */
    public void setRestaurantAddress(Address restaurantAddress) {
        this.restaurantAddress = restaurantAddress;
    }

    /**
     * @return String return the restaurantContact
     */
    public String getRestaurantContact() {
        return restaurantContact;
    }

    /**
     * @param restaurantContact the restaurantContact to set
     */
    public void setRestaurantContact(String restaurantContact) {
        this.restaurantContact = restaurantContact;
    }

    /**
     * @return List<Menu> return the foodList
     */
    public List<Menu> getFoodList() {
        return foodList;
    }

    /**
     * @param foodList the foodList to set
     */
    public void setFoodList(List<Menu> foodList) {
        this.foodList = foodList;
    }


    /**
     * @return boolean return the approved
     */
    public boolean isApproved() {
        return approved;
    }

    /**
     * @param approved the approved to set
     */
    public void setApproved(boolean approved) {
        this.approved = approved;
    }


    /**
     * @return String return the resId
     */
    public String getResId() {
        return resId;
    }

    /**
     * @param resId the resId to set
     */
    public void setResId(String resId) {
        this.resId = resId;
    }

    /**
     * @return String return the resPwd
     */
    public String getResPwd() {
        return resPwd;
    }

    /**
     * @param resPwd the resPwd to set
     */
    public void setResPwd(String resPwd) {
        this.resPwd = resPwd;
    }

    /**
     * @return List<Restaurant> return the allRestaurant
     */
    public List<Restaurant> getAllRestaurant() {
        return allRestaurant;
    }

    /**
     * @param allRestaurant the allRestaurant to set
     */
    public void setAllRestaurant(List<Restaurant> allRestaurant) {
        this.allRestaurant = allRestaurant;
    }

}
