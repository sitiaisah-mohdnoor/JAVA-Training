package com.hcl.foodapp.beans;

public class Menu {
    private String foodName;
    private String foodDescription;
    private double foodPrice;
    private Category foodType;
    

    public Menu(String foodName, String foodDescription, double foodPrice, Category foodType) {
        this.foodName = foodName;
        this.foodDescription = foodDescription;
        this.foodPrice = foodPrice;
        this.foodType = foodType;
    }

    @Override
    public String toString() {
        return "{" +
            " foodName='" + getFoodName() + "'" +
            ", foodDescription='" + getFoodDescription() + "'" +
            ", foodPrice='" + getFoodPrice() + "'" +
            ", foodType='" + getFoodType() + "'" +
            "}";
    }

    /**
     * @return String return the foodName
     */
    public String getFoodName() {
        return foodName;
    }

    /**
     * @param foodName the foodName to set
     */
    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    /**
     * @return String return the foodDescription
     */
    public String getFoodDescription() {
        return foodDescription;
    }

    /**
     * @param foodDescription the foodDescription to set
     */
    public void setFoodDescription(String foodDescription) {
        this.foodDescription = foodDescription;
    }

    /**
     * @return float return the foodPrice
     */
    public double getFoodPrice() {
        return foodPrice;
    }

    /**
     * @param foodPrice the foodPrice to set
     */
    public void setFoodPrice(float foodPrice) {
        this.foodPrice = foodPrice;
    }

    /**
     * @return Category return the foodType
     */
    public Category getFoodType() {
        return foodType;
    }

    /**
     * @param foodType the foodType to set
     */
    public void setFoodType(Category foodType) {
        this.foodType = foodType;
    }

}
