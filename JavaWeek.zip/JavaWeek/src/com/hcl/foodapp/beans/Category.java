package com.hcl.foodapp.beans;

public class Category {
    private String categoryName;
    private String categoryDesc;

    public Category(String categoryName, String categoryDesc) {
        this.categoryName = categoryName;
        this.categoryDesc = categoryDesc;
    }


    @Override
    public String toString() {
        return "{" +
            " categoryName='" + getCategoryName() + "'" +
            ", categoryDesc='" + getCategoryDesc() + "'" +
            "}";
    }
    
    /**
     * @return String return the categoryName
     */
    public String getCategoryName() {
        return categoryName;
    }

    /**
     * @param categoryName the categoryName to set
     */
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    /**
     * @return String return the categoryDesc
     */
    public String getCategoryDesc() {
        return categoryDesc;
    }

    /**
     * @param categoryDesc the categoryDesc to set
     */
    public void setCategoryDesc(String categoryDesc) {
        this.categoryDesc = categoryDesc;
    }

}
