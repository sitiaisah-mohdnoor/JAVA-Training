package com.hcl.foodapp.beans;

public class Customer {
    private String fisrstName;
    private String lastName;
    private String customerPhone;
    private String customerEmail;
    private Address customerAddress;
    private String customerPassword;


    /**
     * @return String return the fisrstName
     */
    public String getFisrstName() {
        return fisrstName;
    }

    /**
     * @param fisrstName the fisrstName to set
     */
    public void setFisrstName(String fisrstName) {
        this.fisrstName = fisrstName;
    }

    /**
     * @return String return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return String return the customerPhone
     */
    public String getCustomerPhone() {
        return customerPhone;
    }

    /**
     * @param customerPhone the customerPhone to set
     */
    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    /**
     * @return String return the customerEmail
     */
    public String getCustomerEmail() {
        return customerEmail;
    }

    /**
     * @param customerEmail the customerEmail to set
     */
    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    /**
     * @return Address return the customerAddress
     */
    public Address getCustomerAddress() {
        return customerAddress;
    }

    /**
     * @param customerAddress the customerAddress to set
     */
    public void setCustomerAddress(Address customerAddress) {
        this.customerAddress = customerAddress;
    }


    /**
     * @return String return the customerPassword
     */
    public String getCustomerPassword() {
        return customerPassword;
    }

    /**
     * @param customerPassword the customerPassword to set
     */
    public void setCustomerPassword(String customerPassword) {
        this.customerPassword = customerPassword;
    }

}
