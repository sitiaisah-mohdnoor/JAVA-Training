package com.hcl.foodapp.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.hcl.foodapp.beans.Address;
import com.hcl.foodapp.beans.Category;
import com.hcl.foodapp.beans.Menu;
import com.hcl.foodapp.beans.Restaurant;

public class RestaurantServiceImpl extends Restaurant implements IRestaurantService{

    public RestaurantServiceImpl() {
    }

    public RestaurantServiceImpl(String resId, String resPwd, String name, Address restaurantAddress,
            String restaurantContact, boolean approved) {
        super(resId, resPwd, name, restaurantAddress, restaurantContact, approved);
    }

    @Override
    public Restaurant authenticateLogin(String accNo, String accPwd){
        Restaurant find = super.getAllRestaurant().stream().filter(Restaurant -> accNo.equals(Restaurant.getResId())).findFirst().orElse(null);
        if(accPwd.equals(find.getResPwd())){
            return find;
        }else{
            return null;
        }
    }

    @Override
    public List<Restaurant> getActiverestaurant() {
        List<Restaurant> filteredList = super.getAllRestaurant().stream().filter(Restaurant -> Restaurant.isApproved()).collect(Collectors.toList());
        return filteredList;
    }

    @Override
    public List<Restaurant> getPendingrestaurant() {
        return super.getAllRestaurant().stream().filter(Restaurant -> !Restaurant.isApproved()).collect(Collectors.toList());
    }

    @Override
    public List<Restaurant> createRestaurant(Restaurant res) {
        List<Restaurant> resList = super.getAllRestaurant();
        // System.out.println("before adding "+resList);
        Restaurant newRes = new Restaurant();
        newRes.setResId(res.getResId());;
        newRes.setResPwd(res.getResPwd());
        newRes.setName(res.getName());
        newRes.setRestaurantContact(res.getRestaurantContact());
        newRes.setApproved(res.isApproved());
        newRes.setRestaurantAddress(res.getRestaurantAddress());
        resList.add(newRes);
        // System.out.println("updated list"+resList);
        return resList;
    }

    @Override
    public Restaurant addMenu(Restaurant res) {
        List<Menu> foodList = new ArrayList<>();
        Menu menu1 = new Menu("Chicken Rice", "steam rice with grilled chicken", 10.00, new Category("Asian", "blablabla"));
        Menu menu2 = new Menu("Pasta Alfredo", "creamy pasta with mushroom", 15.00, new Category("Western", "blablabla"));
        foodList.add(menu1);
        foodList.add(menu2);
        res.setFoodList(foodList);
        return res;
    }

    @Override
    public Restaurant approveRestaurant(Restaurant res) {
        res.setApproved(true);
        return res;
    }

    @Override
    public List<Menu> menuList(Restaurant res) {
        return res.getFoodList();
    }
}
