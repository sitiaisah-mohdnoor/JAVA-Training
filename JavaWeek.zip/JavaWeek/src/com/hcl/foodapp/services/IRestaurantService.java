package com.hcl.foodapp.services;

import java.util.List;

import com.hcl.foodapp.beans.Menu;
import com.hcl.foodapp.beans.Restaurant;

public interface IRestaurantService {

    public Restaurant authenticateLogin(String accNo, String accPwd);
    public List<Restaurant> getActiverestaurant();
    public List<Restaurant> getPendingrestaurant();
    public List<Restaurant> createRestaurant(Restaurant res);
    public Restaurant addMenu(Restaurant res);
    public Restaurant approveRestaurant(Restaurant res);
    public List<Menu> menuList(Restaurant res);
}
