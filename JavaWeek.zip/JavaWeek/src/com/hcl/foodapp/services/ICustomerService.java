package com.hcl.foodapp.services;

public interface ICustomerService {
    
}
