package com.hcl.foodapp.services;
import com.hcl.foodapp.beans.Admin;
public interface IAdminService{
    
    public String authenticateAdmin(String usr, String pwd, Admin admin);

}
