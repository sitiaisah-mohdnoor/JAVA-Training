package com.hcl.foodapp.services;

import com.hcl.foodapp.beans.Admin;

public class AdminServiceImpl implements IAdminService{

    @Override
    public String authenticateAdmin(String usr, String pwd, Admin admin) {
        if(usr.equals(admin.getAdminEmail()) && pwd.equals(admin.getAdminPwd())){
            return "successfull";
        }else{
            return "failed, please try again";
        }
    }
    
}
