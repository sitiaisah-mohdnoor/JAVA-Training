package com.hcl.calculator.demo;

import java.util.Scanner;

public class App {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("input1: ");
        int ipt1 = scan.nextInt();
        System.out.print("input2: ");
        int ipt2 = scan.nextInt();
        System.out.println("result "+addition(ipt1, ipt2)); 
        System.out.println("result "+subtraction(ipt1, ipt2)); 
        System.out.println("result "+multiplication(ipt1, ipt2)); 
        if(ipt2 == 0){
            System.out.println("cant be divided by 0");
        }else{
            System.out.println("result "+division(ipt1, ipt2)); 
        }
        System.out.println(interchange(ipt1, ipt2)); 
        System.out.print("input no : ");
        int ipt3 = scan.nextInt();
        pattern(ipt3);
        System.out.print("input no to be reverse : ");
        int ipt4 = scan.nextInt();
        reverse(ipt4);
    }

    static int addition(int a, int b){
        return a+b;
    }
    static int subtraction(int a, int b){
        return b-a;
    }
    static int multiplication(int a, int b){
        return a*b;
    }
    static int division(int a, int b){
        return a/b;
    }
    static String interchange(int a, int b){
        a += b;
        b = a-b;
        a -= b;
        return a+"\n"+b;
    }
    static void pattern(int num){
        int n = 1;
        for(int i = 1; i <= num; i++){
            for(int j = 1; j <= i; j++){
                System.out.print(n++);
            }
            System.out.println();
        }
    }
    static void reverse(int num){
        int reversed = 0;

        for(;num != 0; num /= 10) {
          int digit = num % 10;
          reversed = reversed * 10 + digit;
        }
    
        System.out.println("Reversed Number: " + reversed);
    }
}
