package com.hcl.property.beans;
/**
 * each propert will hv assocoated property tax
 * properties category -- Apartments, RowHouse
 */
public class Property {
    
}
