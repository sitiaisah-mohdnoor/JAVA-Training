package com.hcl.property.beans;

public class Address {
    
}
