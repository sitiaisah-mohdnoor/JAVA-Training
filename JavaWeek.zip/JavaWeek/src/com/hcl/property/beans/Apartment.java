package com.hcl.property.beans;

public class Apartment extends Property{
    
}
