package com.hcl.property.beans;

public class RowHouse extends Property{
    
}
