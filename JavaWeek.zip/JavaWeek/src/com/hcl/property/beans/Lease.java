package com.hcl.property.beans;
/**
 * move in and move out date cant be empty while creating lease
 * 
 * move in date cant be after ove out date
 */

import java.time.LocalDate;

public class Lease {
    private Resident resident;
    private int id;
    private LocalDate moveInDate;
    private LocalDate moveOutDate;
    private Property property;

    public Lease(Resident resident, int id, LocalDate moveInDate, LocalDate moveOutDate, Property property) {
        this.resident = resident;
        this.id = id;
        this.moveInDate = moveInDate;
        this.moveOutDate = moveOutDate;
        this.property = property;
    }

    /**
     * @return Resident return the resident
     */
    public Resident getResident() {
        return resident;
    }

    /**
     * @param resident the resident to set
     */
    public void setResident(Resident resident) {
        this.resident = resident;
    }

    /**
     * @return int return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return LocalDate return the moveInDate
     */
    public LocalDate getMoveInDate() {
        return moveInDate;
    }

    /**
     * @param moveInDate the moveInDate to set
     */
    public void setMoveInDate(LocalDate moveInDate) {
        this.moveInDate = moveInDate;
    }

    /**
     * @return LocalDate return the moveOutDate
     */
    public LocalDate getMoveOutDate() {
        return moveOutDate;
    }

    /**
     * @param moveOutDate the moveOutDate to set
     */
    public void setMoveOutDate(LocalDate moveOutDate) {
        this.moveOutDate = moveOutDate;
    }

    /**
     * @return Property return the property
     */
    public Property getProperty() {
        return property;
    }

    /**
     * @param property the property to set
     */
    public void setProperty(Property property) {
        this.property = property;
    }

}
