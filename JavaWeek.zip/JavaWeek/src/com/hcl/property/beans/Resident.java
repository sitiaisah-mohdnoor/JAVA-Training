package com.hcl.property.beans;
/**
 * Resident can rent a type of property from available list
 * pay monthly rent as agreed and become tenant
 * if no available rental property, throw error
 */
public class Resident {
    private int socialId;
    private String firstName;
    private String lastName;
    private boolean tenant;

    public Resident(int socialId, String firstName, String lastName, boolean tenant) {
        this.socialId = socialId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.tenant = tenant;
    }

    /**
     * @return int return the socialId
     */
    public int getSocialId() {
        return socialId;
    }

    /**
     * @param socialId the socialId to set
     */
    public void setSocialId(int socialId) {
        this.socialId = socialId;
    }

    /**
     * @return String return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return String return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return boolean return the tenant
     */
    public boolean isTenant() {
        return tenant;
    }

    /**
     * @param tenant the tenant to set
     */
    public void setTenant(boolean tenant) {
        this.tenant = tenant;
    }

}
