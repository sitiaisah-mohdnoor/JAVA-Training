package com.hcl.property.beans;
/**
 * can vacate property either end of the lease or
 * give 1 month notice period
 * 
 * one tenant cant hv multiple properties
 * 
 * multiple tenant can be assigned to single property
 */
public class Tenant {
    
}
