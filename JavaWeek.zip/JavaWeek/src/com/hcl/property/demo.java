package com.hcl.property;
/**
 * Property Rental Management System
 */
public class demo {
    public static void main(String[] args) {
        //create new Resident obj

        //create Address
        //create Apartment as Property

        //create Address
        //create RowHouse as Property

        //create Lease
    }
}
