package com.hcl.training.week1;

public class TechDepartment extends SuperDepartment{
    public String deparmentName() {
		return "Tech Department";
	}

	public String getTodaysWork() {
		return "Complete coding of module 1";
	}

	public String getTechStackInformation() {
		return "Core Java";
	}
	
	public String getWorkDeadline() {
		return "Complete by EOD";
	}
}
