package com.hcl.training.week1;

public class Main {
    public static void main(String[] args){

        SuperDepartment sd = new SuperDepartment();
        System.out.println(sd.deparmentName());
		System.out.println(sd.getTodaysWork());
		System.out.println(sd.getWorkDeadline());
        System.out.println(sd.isTodayAHoliday());
        System.out.println("--------------------------");

        // create the object of AdminDepartment and use all the methods 
		AdminDepartment ad = new AdminDepartment();
        System.out.println(ad.deparmentName());
		System.out.println(ad.getTodaysWork());
		System.out.println(ad.getWorkDeadline());
        System.out.println(ad.isTodayAHoliday());
        System.out.println("--------------------------");
		
		// create the object of Hr Department and use all the methods 
		HrDepartment hd = new HrDepartment();
        System.out.println(hd.deparmentName());
		System.out.println(hd.getTodaysWork());
		System.out.println(hd.getWorkDeadline());
        System.out.println(hd.doActivity());
        System.out.println(hd.isTodayAHoliday());
        System.out.println("--------------------------");
				
		// create the object of TechDepartment and use all the methods 
		TechDepartment td = new TechDepartment();
        System.out.println(td.deparmentName());
		System.out.println(td.getTodaysWork());
		System.out.println(td.getWorkDeadline());
        System.out.println(td.getTechStackInformation());
        System.out.println(td.isTodayAHoliday());
        System.out.println("--------------------------");
    }
    
}
