package com.hcl.training.week1;

public class AdminDepartment extends SuperDepartment{
    public String deparmentName() {
		return "Admin Department";
	}

	public String getTodaysWork() {
		return "Complete your documents Submission";
	}

	public String getWorkDeadline() {
		return "Complete by EOD";
	}

}
